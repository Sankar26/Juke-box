app.constant("API",function(){

    "studentInfo":"http:9078.78.90.56/att/jdhkjd",


})