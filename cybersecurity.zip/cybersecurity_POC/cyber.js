var runid;

function generateRunID(){
    var cdate = new Date();
    var chours = cdate.getHours().toString();
    var cmins = cdate.getMinutes().toString();
    var strun = chours+cmins;
    console.log("RUNID " + strun);
    return strun;
}

function runTest(){
    var returnData;
    runid = generateRunID();
    var strrunid = runid+"--49.204.201.168";
    console.log(strrunid);
    $.getJSON('http://139.59.138.87/testscan2.php?jsoncallback=?',{ strrunid },
                    function(response){
                        console.log(response.length);
                    });
}

function runTestWithCheck(){
    $.getJSON('http://localhost/cybersecurity/test.php',
                    function(response,status,xhr){
                        console.log(response.length);
                        if(xhr.status == 200){
			$("#runtest").css("display", "block");
			runTest();}
			else{
			alert("Please connect pendrive and run this page again.");
				}
                    });

}

function getData(){

                var returnData;
                console.log(runid);
                //var runid = 4;
                $.getJSON(
                    'http://139.59.138.87/demo2.php?jsoncallback=?',{ runid },
                    function(response){
                        console.log(response.length);
			if(response.length > 0){
				 $("#runtest").css("display", "none");
				}
			else{
				alert("Your request is still running. Please try again after sometime.");
			}
                        var out = "";
                         $.each(response, function(k, v){
                             console.log(v.mailserver_rat + ' ' + v.domsec_rat + ' ' + v.portm_rat + ' ' + v.cookies_rat);
                             //out += '<a href="">' + v.desig + ' ' + v.name + '</a><br>';
                         });
                         for(var i=0; i < response.length; i++){
                             //out += '<a href="">' + response[i].firewall_rat + ' ' + response[i].mailserver_rat +'</a><br>';
                             jQuery("#firewall").radialProgress("init", {
                                'size': 100,
                                'fill': 10,
                                'color': 'rgb(238, 53, 127)'
                                }).radialProgress("to", {'perc': response[i].firewall_rat, 'time': 1000}),
                             jQuery("#firewall .text").text("FIREWALL"),
                             jQuery("#firewall2").text("FIREWALL"),
                             jQuery("#firewallcomm").text(response[i].firewall_comm),
                             jQuery("#mailserver").radialProgress("init", {
                                'size': 100,
                                'fill': 10,
                                'color': 'rgb(238, 53, 127)'
                                }).radialProgress("to", {'perc': response[i].mailserver_rat, 'time': 1000}),
                             jQuery("#mailserver .text").text("MAIL SERVER"),
                             jQuery("#mailserver2").text("MAIL SERVER"),
                             jQuery("#mailservercomm").text(response[i].mailserver_comm),
                             jQuery("#ddos").radialProgress("init", {
                                'size': 100,
                                'fill': 10,
                                'color': 'rgb(9, 140, 205)'
                                }).radialProgress("to", {'perc': response[i].ddos_rat, 'time': 1000}),
                             jQuery("#ddos .text").text("DDOS SECURITY"),
                             jQuery("#ddos2").text("DDOS SECURITY"),
                             jQuery("#ddoscomm").text(response[i].ddos_comm),
                             jQuery("#domsec").radialProgress("init", {
                                'size': 100,
                                'fill': 10,
                                'color': 'rgb(9, 140, 205)'
                                }).radialProgress("to", {'perc': response[i].domsec_rat, 'time': 1000}),
                             jQuery("#domsec .text").text("DOMAIN SECURITY"),
                             jQuery("#domsec2").text("DOMAIN SECURITY"),
                             jQuery("#domseccomm").text(response[i].domsec_comm),
                             jQuery("#portm").radialProgress("init", {
                                'size': 100,
                                'fill': 10,
                                'color': 'rgb(203, 220, 60)'
                                }).radialProgress("to", {'perc': response[i].portm_rat, 'time': 1000}),
                             jQuery("#portm .text").text("PORTS MONITORING"),
                             jQuery("#portm2").text("PORTS MONITORING"),
                             jQuery("#portmcomm").text(response[i].portm_comm),
                             jQuery("#cookies").radialProgress("init", {
                                'size': 100,
                                'fill': 10,
                                'color': 'rgb(203, 220, 60)'
                                }).radialProgress("to", {'perc': response[i].cookies_rat, 'time': 1000}),
                             jQuery("#cookies .text").text("COOKIES"),
                             jQuery("#cookies2").text("COOKIES"),
                             jQuery("#cookiescomm").text(response[i].cookies_comm);
                             //console.log(response[i].domsec_rat);
                          }
                         //document.getElementById("id01").innerHTML = out;
                    })
}

        $("#portm2").click(function(){
            $("#main").addClass("hid");
            $("#main2").css("display", "block");
            console.log("Run Id: " + runid);
            $.getJSON('http://139.59.138.87/demo2.php?jsoncallback=?',{ runid },
                function(response){
                    console.log(response.length);
                    $.each(response, function(k, v){
                             console.log(v.mailserver_rat + ' ' + v.domsec_rat + ' ' + v.portm_rat + ' ' + v.cookies_rat);
                         });
                    jQuery("#titl").text("PORTS MONITORING");
                    for(var i=0; i < response.length; i++){
                        jQuery("#portmd").radialProgress("init", {
                                'size': 100,
                                'fill': 10,
                                'color': 'rgb(203, 220, 60)'
                                }).radialProgress("to", {'perc': response[i].portm_rat, 'time': 1000}),
                        jQuery("#portmdes").text(response[i].portm_comm);
                    }
                }),

            $.getJSON('http://139.59.138.87/ports.php?jsoncallback=?', { runid },
                function(response){
                    console.log(response.length);
                    // $.each(response, function(k, v){
                    //          console.log(v[0].port_id + ' ' + v[0].port_title + ' ' + v[0].port_rating + ' ' + v[0].port_status);
                    //          jQuery("#portitle1").text(v[0].port_title);
                    //          jQuery("#pordesc1").text(v[0].port_comment);
                    //      });
                    console.log(response[1][0].port_title);
                    jQuery("#portitle1").text(response[0][0].port_title + ' (' +response[0][0].port_id + ')' );
                    jQuery("#pordesc1").text(response[0][0].port_comment);
                    jQuery("#portitle2").text(response[1][0].port_title  + ' (' +response[1][0].port_id + ')');
                    jQuery("#pordesc2").text(response[1][0].port_comment);
                    jQuery("#portitle3").text(response[2][0].port_title  + ' (' +response[2][0].port_id + ')');
                    jQuery("#pordesc3").text(response[2][0].port_comment);
                    jQuery("#portitle4").text(response[3][0].port_title  + ' (' +response[3][0].port_id + ')');
                    jQuery("#pordesc4").text(response[3][0].port_comment);
                    jQuery("#portitle5").text(response[4][0].port_title  + ' (' +response[4][0].port_id + ')');
                    jQuery("#pordesc5").text(response[4][0].port_comment);
                    jQuery("#portitle6").text(response[5][0].port_title  + ' (' +response[5][0].port_id + ')');
                    jQuery("#pordesc6").text(response[5][0].port_comment);
                    jQuery("#portitle7").text(response[6][0].port_title  + ' (' +response[6][0].port_id + ')');
                    jQuery("#pordesc7").text(response[6][0].port_comment);
                    jQuery("#portitle8").text(response[7][0].port_title  + ' (' +response[7][0].port_id + ')');
                    jQuery("#pordesc8").text(response[7][0].port_comment);
                    jQuery("#portitle9").text(response[8][0].port_title  + ' (' +response[8][0].port_id + ')');
                    jQuery("#pordesc9").text(response[8][0].port_comment);
                    jQuery("#portitle10").text(response[9][0].port_title  + ' (' +response[9][0].port_id + ')');
                    jQuery("#pordesc10").text(response[9][0].port_comment);
                    jQuery("#portitle11").text(response[10][0].port_title  + ' (' +response[10][0].port_id + ')');
                    jQuery("#pordesc11").text(response[10][0].port_comment);
                    jQuery("#portitle12").text(response[11][0].port_title  + ' (' +response[11][0].port_id + ')');
                    jQuery("#pordesc12").text(response[11][0].port_comment);
                    jQuery("#portitle13").text(response[12][0].port_title  + ' (' +response[12][0].port_id + ')');
                    jQuery("#pordesc13").text(response[12][0].port_comment);
                    jQuery("#portitle14").text(response[13][0].port_title  + ' (' +response[13][0].port_id + ')');
                    jQuery("#pordesc14").text(response[13][0].port_comment);
                    jQuery("#portitle15").text(response[14][0].port_title  + ' (' +response[14][0].port_id + ')');
                    jQuery("#pordesc15").text(response[14][0].port_comment);
                    jQuery("#portitle16").text(response[15][0].port_title  + ' (' +response[15][0].port_id + ')');
                    jQuery("#pordesc16").text(response[15][0].port_comment);
                    jQuery("#portitle17").text(response[16][0].port_title  + ' (' +response[16][0].port_id + ')');
                    jQuery("#pordesc17").text(response[16][0].port_comment);
                    jQuery("#portitle18").text(response[17][0].port_title  + ' (' +response[17][0].port_id + ')');
                    jQuery("#pordesc18").text(response[17][0].port_comment);
                    jQuery("#portitle19").text(response[18][0].port_title  + ' (' +response[18][0].port_id + ')');
                    jQuery("#pordesc19").text(response[18][0].port_comment);
                    jQuery("#portitle20").text(response[19][0].port_title  + ' (' +response[19][0].port_id + ')');
                    jQuery("#pordesc20").text(response[19][0].port_comment);
                    jQuery("#portitle21").text(response[20][0].port_title  + ' (' +response[20][0].port_id + ')');
                    jQuery("#pordesc21").text(response[20][0].port_comment);
                    jQuery("#portitle22").text(response[21][0].port_title  + ' (' +response[21][0].port_id + ')');
                    jQuery("#pordesc22").text(response[21][0].port_comment);
                    jQuery("#portitle23").text(response[22][0].port_title  + ' (' +response[22][0].port_id + ')');
                    jQuery("#pordesc23").text(response[22][0].port_comment);
                    jQuery("#portitle24").text(response[23][0].port_title  + ' (' +response[23][0].port_id + ')');
                    jQuery("#pordesc24").text(response[23][0].port_comment);
                    jQuery("#portitle25").text(response[24][0].port_title  + ' (' +response[24][0].port_id + ')');
                    jQuery("#pordesc25").text(response[24][0].port_comment);
                    jQuery("#portitle26").text(response[25][0].port_title  + ' (' +response[25][0].port_id + ')');
                    jQuery("#pordesc26").text(response[25][0].port_comment);
                    jQuery("#portitle27").text(response[26][0].port_title  + ' (' +response[26][0].port_id + ')');
                    jQuery("#pordesc27").text(response[26][0].port_comment);
                    jQuery("#portitle28").text(response[27][0].port_title  + ' (' +response[27][0].port_id + ')');
                    jQuery("#pordesc28").text(response[27][0].port_comment);
                    jQuery("#portitle29").text(response[28][0].port_title  + ' (' +response[28][0].port_id + ')');
                    jQuery("#pordesc29").text(response[28][0].port_comment);
                    jQuery("#portitle30").text(response[29][0].port_title  + ' (' +response[29][0].port_id + ')');
                    jQuery("#pordesc30").text(response[29][0].port_comment);
                    jQuery("#portitle31").text(response[30][0].port_title  + ' (' +response[30][0].port_id + ')');
                    jQuery("#pordesc31").text(response[30][0].port_comment);
                    jQuery("#portitle32").text(response[31][0].port_title  + ' (' +response[31][0].port_id + ')');
                    jQuery("#pordesc32").text(response[31][0].port_comment);
                    jQuery("#portitle33").text(response[32][0].port_title  + ' (' +response[32][0].port_id + ')');
                    jQuery("#pordesc33").text(response[32][0].port_comment);
                    jQuery("#portitle34").text(response[33][0].port_title  + ' (' +response[33][0].port_id + ')');
                    jQuery("#pordesc34").text(response[33][0].port_comment);
                    jQuery("#portitle35").text(response[34][0].port_title  + ' (' +response[34][0].port_id + ')');
                    jQuery("#pordesc35").text(response[34][0].port_comment);
                    jQuery("#portitle36").text(response[35][0].port_title  + ' (' +response[35][0].port_id + ')');
                    jQuery("#pordesc36").text(response[35][0].port_comment);
                    // jQuery("#portitle37").text(response[36][0].port_title  + ' (' +response[36][0].port_id + ')');
                    // jQuery("#pordesc37").text(response[36][0].port_comment);
                    // jQuery("#portitle38").text(response[37][0].port_title  + ' (' +response[37][0].port_id + ')');
                    // jQuery("#pordesc38").text(response[37][0].port_comment);
                    // var j=0;
                    // for(var i=0; i < response.length; i++){
                    //     console.log(response[i][0].port_title);
                    //     j++;
                    // }
                })
        });

        
        // function sendresults(){
        //     $("#runtest").css("display", "block");
        // }

        // $("#res").on("click", "getData()");

function sendresults(){
    //$("#runtest").css("display", "block");
    runTestWithCheck();
    $("#res").click(function(e){
        //$("#runtest").css("display", "none"); 
            e.preventDefault();
            getData();
        });
}