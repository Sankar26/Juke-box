var mainApp = angular.module("mainApp", []);
		mainApp.controller('studentController', function($scope){
			$scope.reset = function(){
               $scope.firstName = "Mahesh";
               $scope.lastName = "Parashar";
               $scope.email = "MaheshParashar@tutorialspoint.com";
            }
            $scope.reset();
		});




// var mainApp = angular.module("mainApp", []);
// mainApp.controller('studentController', function($scope){
// 		$scope.reset = function(){
// 			$.getJSON(
//                     'http://139.59.138.87/demo.php?jsoncallback=?',
//             //'http://ipinfo.io/json?jsoncallback=?',
//                     function(response){
//                     	$scope.firstName = response.name;
//                         alert(response.designation);
//                         console.log(response.name);
//                         console.log(response.designation);
//                     })
// 		}
// 		$scope.reset();
// 	});