'use strict';




app.controller('homeController', function ($timeout, $state, $http) {

    

    self.date = moment().format('ddd Do MMMM, YYYY');


    self.loadDetails = function (item) {

        $state.go('details', { item: item });


    };

    /*
    self.start = function() {
        self.label = self.value;
        timeout = $timeout(function() {
            self.value+=10;
            if(self.value > self.max) {
                self.value = 0;
            }
            self.start();
        }, 1000);
    };
    self.start();
*/
$http.get('data/security.json')
    .success(function(response){
    $scope.item=response;
};
       
    });



});

