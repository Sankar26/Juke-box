app.controller('quickFix', function ($scope) {
    $scope.d =  moment().format('ddd Do MMMM, YYYY');
});