app.controller('detailsController', function ($stateParams, $state) {

    

    var self = this;
    self.item = $stateParams.item;

    self.getImage = function (item) {

        console.log(JSON.stringify(item));

       switch(item.status){
           case 0:
               return "img/ok.png";
               break;
           case 1:
               return "img/notoknotbad.png";
               break;
           case 2:
               return "img/notok.png";
               break;
       }
    };
    self.goHome = function () {
        $state.go('home');
    }
});