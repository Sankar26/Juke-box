'use strict';


var app = angular.module('cybersecurity', [

    'ui.router',
    'ngAnimate',
    'angular-circular-progress',
    'hj.gsapifyRouter'
]);
