'use strict';


app.config(function ($stateProvider, $urlRouterProvider, gsapifyRouterProvider) {


    $urlRouterProvider.otherwise('/'); //404'ed


    /**
     * Insert pageBody to ui view when dealing with animaitons
     * else exiting page happens to be under the entering page
     */

    gsapifyRouterProvider.defaults = {
        enter: 'slideRight',
        leave: 'slideLeft'
    };

    // Optionally enable transition on initial load
    gsapifyRouterProvider.initialTransitionEnabled = false; // defaults to false

    gsapifyRouterProvider.transition('slideLeft', {
        duration: 0.5,
        css: {
            x: '-100%'
        }
    });

    gsapifyRouterProvider.transition('slideRight', {
        duration: 0.5,
        delay: 0.0,
        css: {
            x: '100%'
        }
    });

    gsapifyRouterProvider.transition('fadeIn', {
        duration: 0.5,
        delay: 0.5,
        css: {
            opacity: 0
        }
    });

    gsapifyRouterProvider.transition('fadeOut', {
        duration: 0.5,
        css: {
            opacity: 0
        }
    });

    $stateProvider
        .state('home', {
            url: '/',
            views: {
                main: {
                    templateUrl: 'views/home.htm',
                    controller: 'homeController',
                    controllerAs: 'hc'
                }
            },
            data: {
                'gsapifyRouter.main': {
                    enter: {
                        in: {
                            transition: 'slideLeft',
                            priority: 2
                        },
                        out: {
                            transition: 'slideRight',
                            priority: 1
                        }
                    }
                }
            }
        })
        .state('details', {
            url: '/details',
            params: { item: null },
            views: {
                main:{
                    controller: 'detailsController',
                    controllerAs: 'dc',
                    templateUrl: 'views/details.htm'
                }

            },
            data: {
                'gsapifyRouter.main': {
                    enter: {
                        in: {
                            transition: 'slideRight',
                            priority: 1
                        },
                        out: {
                            transition: 'slideLeft',
                             priority: 2
                        }
                    }
                }
            }
        })
});





