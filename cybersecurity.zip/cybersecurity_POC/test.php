<?php

echo json_encode("1");

?>