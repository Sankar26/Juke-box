function details(){
	$.getScript('cyber.js', function(){
	alert("Script is loaded...");
	alert(runid.value());
	});
}