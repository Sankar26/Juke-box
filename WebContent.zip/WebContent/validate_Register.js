function validate()
{ 

  if( document.registration.Username.value == "" )
  {
     alert( "Please provide your Name!" );
     document.registration.Username.focus() ;
     return false;
  }
   
  var email = document.registration.emailid.value;
  at = email.indexOf("@");
  dot = email.lastIndexOf(".");
  if (email == "" || at < 1 || ( dot - at < 2 )) 
  {
     alert("Please enter correct email ID")
     document.registration.emailid.focus() ;
     return false;
  }

  var pwd=document.registration.password.value;
  if(pwd="" || pwd.length < 8)
  {
     alert( "Please Enter password of length minimum 8 characters" );
     document.registration.password.focus() ;
     return false;
  }

 
  
  if( document.registration.fname.value == "" )
  {
     alert( "Please provide your First Name!" );
     document.registration.fname.focus() ;
     return false;
  }

  if( document.registration.lname.value == "" )
  {
     alert( "Please provide your Last Name!" );
     document.registration.lname.focus() ;
     return false;
  }

  if( document.registration.dob.value == "" )
  {
     alert( "Please provide your DOB!" );
     document.registration.dob.focus() ;
     return false;
  }

  if ( ( registration.sex[0].checked == false ) && ( registration.sex[1].checked == false ) )
  {
     alert ( "Please choose your Gender: Male or Female" );
     return false;
  }  

  if( document.registration.address.value == "" )
  {
     alert( "Please provide your Address!" );
     document.registration.address.focus() ;
     return false;
  } 
     
  if( document.registration.mobileno.value == "" || isNaN( document.registration.mobileno.value) ||  document.registration.mobileno.value.length != 10 )
  {
     alert( "Please provide a Mobile No in the format 123." );
     document.registration.mobileno.focus() ;
     return false;
  }
  return( true );
}