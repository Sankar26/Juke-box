angular.module('app', [])
.controller('AppCtrl', function($scope){
  $scope.data = {};
    $scope.name = "world";
    
  
  $scope.saveName = function(){
   if($scope.data.firstName && $scope.data.lastName)
   
   {
   $scope.name = $scope.data.firstName+ " " + $scope.data.lastname
  }
  else {
    alert("please fill out the fields before submitting !");
  };
  }
});