var app=angular.module('appAdmin');
app.controller('agentsCtrl', function($scope,agentsSvc) {

    GetAgentsList()
    function GetAgentsList() {



//service call//
    agentsSvc.getAgentsList()
        .then(function (response) {

            $scope.agents = response;
            $scope.selectedRow = 1;
            console.log('print')
        })

        .catch(function (errorResponse) {
            $scope.error = "Error response";
        });
}
    $scope.setClickedRow=function (index) {
        $scope.selectedRow=index;
    }

    // Add Row
    $scope.addUser = function(newUser) {
       var agent ={'Id':newUser.Id, 'UserName':newUser.UserName, 'email':newUser.email,'phoneNumber':newUser.phoneNumber,
            'address':newUser.address,'pancard':newUser.pancard,'accountDetails':newUser.accountDetails,'marchentId':newUser.marchentId}
            $scope.agents.push(agent);
            agentsSvc.AddEmp(agent)
                getAgentsList()
        };



        // Delete Row//
    $scope.removeRow = function (item) {
        // $scope.editmode = true;
        // $scope.agents.splice(agent, 1);
        var resultArr = [];
        angular.forEach($scope.agents,function (agent) {
            if(item.Id !== agent.Id){
                resultArr.push(agent);
            }
        });
        $scope.agents = resultArr;

    };


    $scope.check = "";
    $scope.editmn = true;
    $scope.showfrm = false;

    //Edit row//
    $scope.edit = function(item) {
        $scope.editmode = true;
        $scope.agent = angular.copy($scope.agent);
    }
    //Cancel
    $scope.cancel = function() {
        $scope.editmode = false;
        $scope.agent = {};
    }
    //Save
    $scope.save = function() {
        $scope.agent.Id = $scope.agent.Id;
        $scope.agent.UserName = $scope.agent.UserName;
        $scope.agent.email= $scope.agent.email;
        $scope.agent.phoneNumber = $scope.agent.phoneNumber;
        $scope.agent.address = $scope.agent.address;
        $scope.agent.pancard = $scope.agent.pancard;
        $scope.agent.accountDetails = $scope.accountDetails;
        $scope.editmode = false;
        var getData = agentsSvc.getEdit($scope.agent);
        getData.then(function (msg) {
            GetAgentsList()
            alert(msg.data);
            $scope.divEmployee = false;
        }, function () {
            alert('Error in updating record');
        });
         $scope.resetAll({});
    }


    $scope.resetAll = function(agent) {
        angular.forEach($scope.agents, function(val) {


            if (val.Id !== agent.Id) {
                val.checked = false;

            } else {

                $scope.agent = val;
                $scope.editmn = !val.checked;
            }

        });
    }

    function ClearFields() {
        $scope.agent = "";
        $scope.employeeName = "";
        $scope.employeeEmail = "";
        $scope.employeeAge = "";
    }

    });