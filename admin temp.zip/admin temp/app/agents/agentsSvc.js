var app=angular.module('appAdmin');
app.service('agentsSvc',function($http, $q){

    this.getAgentsList=function(){
        var dfd=$q.defer();
        $http({
            method: "GET",
            // url: 'http://localhost:80/newspaper_app/public/admin/agent'
            url:'app/data/agents.json'
        })
        .then(function(response){
            var profilesArr = [];
            angular.forEach(response.data.profiles, function (profile) {
                profile.checked = false;
                profilesArr.push(profile);
            });
            dfd.resolve(profilesArr);
        })
            .catch(function(response){
                dfd.reject("Error Occured");
            });
        return dfd.promise;
    }
        this.getEdit = function (agent) {
            var dfd = $q.defer();
            $http({
                method: "post",
                // url: 'http://localhost:80/newspaper_app/public/admin/agent',
                url:'app/data/agents.json',
                // data:$scope.agents,
                data:JSON.stringify(agent),
                dataType: "json"
                // params: {
                //     id: JSON.stringify(agent)
                // }
            })

            .then(function(response){
                dfd.resolve(response.data);
            })
            .catch(function(response){
                dfd.reject("Error Occured");
            })
        return dfd.promise;
    }
    this.AddEmp = function (agent) {
        var response = $http({
            method: "post",
            // url: 'http://localhost:80/newspaper_app/public/admin/agent',
            url:'app/data/agents.json',
            data: JSON.stringify(agent),
            dataType: "json"
        })

        .then(function(response){
            dfd.resolve(response.data);
        })
            .catch(function(response){
                dfd.reject("Error Occured");
            })
        return dfd.promise;


    }
});
