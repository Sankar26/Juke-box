'use strict';
var app = angular.module('appAdmin');
app.controller('registerCtrl', function($scope){
   $scope.message="Welcome";
});