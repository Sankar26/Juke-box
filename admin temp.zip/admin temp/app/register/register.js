'use strict';
app = angular.module('appAdmin.register',[]);