'use strict';
app = angular.module('appAdmin.home',[]);