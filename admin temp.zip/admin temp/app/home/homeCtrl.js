'use strict';
var app = angular.module('appAdmin');
app.controller('homeCtrl', function(){



});

