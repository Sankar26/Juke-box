'use strict';
var app = angular.module('appAdmin',['ngRoute']);
app.config(['$routeProvider',function($routeProvider){

    $routeProvider
        .when("/home",{
            templateUrl: "app/home/home.html",
            controller:"homeCtrl"
        })


        .when("/agents",{

            templateUrl:"app/agents/agent.html",
            controller:"agentsCtrl"

        })


         .otherwise({redirectTo:'/home'});

}]);







